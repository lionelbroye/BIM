# BIM
Penser une blockchain qui définit le temps à partir de la création d’un bloc originel (genesis) qui marque la naissance de ce temps 0.
Chaque bloc est le marqueur du temps, sa création est réglée par une constante de création calculée à partir des coefficients de marée.
