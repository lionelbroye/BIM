using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Diagnostics;
using System.Numerics;
using firstchain.arith256;
using System.Threading;
using System.Timers;

namespace firstchain
{
    /*
     * Revoir la gestion des fichiers ( temp dl concat && proccess ) dans le main loop ( nullexception et outofrangeexception se produit par moment )
     * Pour l'instant c'est toléré dans un try catch de la fonction Main(). a rendre propre.  
     */
    class Program
    {
        public class Block
        {
            public uint Index { get; } // 4 o
            public byte[] Hash { get; } // 32 o
            public byte[] previousHash { get; } // 32 o
            public uint DataSize { get; } // 4 o
            public List<Tx> Data { get; } // 1100 o * datasize
            public uint TimeStamp { get; } // 4 o
            public MinerToken minerToken { get; } // 40 o
            public byte[] HashTarget { get; } // 32 o
            public uint Nonce { get; } // 4 o 

            public Block(uint index, byte[] hash, byte[] ph, List<Tx> data, uint ts, MinerToken mt, byte[] hashtarget, uint nonce)
            {
                this.Index = index;
                this.Hash = hash;
                this.previousHash = ph;
                this.Data = data;
                this.TimeStamp = ts;
                this.minerToken = mt;
                this.HashTarget = hashtarget;
                this.Nonce = nonce;
                this.DataSize = (uint)data.Count;
            }

        }
        public class Tx
        {
            public byte[] sPKey { get; }
            public uint Amount { get; }
            public byte[] rHashKey { get; }
            public uint LockTime { get; }
            public uint sUTXOP { get; }
            public uint rUTXOP { get; }
            public uint TokenOfUniqueness { get; }
            public uint TxFee { get; }
            public byte[] Signature { get; }


            public Tx(byte[] spk, uint amount, byte[] rpk, uint locktime, uint spkP, uint rpkP, uint TOU, uint Fee, byte[] sign)
            {
                this.sPKey = spk;
                this.Amount = amount;
                this.rHashKey = rpk;
                this.LockTime = locktime;
                this.sUTXOP = spkP;
                this.rUTXOP = rpkP;
                this.TokenOfUniqueness = TOU;
                this.TxFee = Fee;
                this.Signature = sign;
            }
        }
        public class UTXO
        {
            public byte[] HashKey { get; }
            public uint TokenOfUniqueness { get; }
            public uint Sold { get; }

            public UTXO(byte[] pKey, uint sold, uint TOU)
            {
                this.HashKey = pKey;
                this.Sold = sold;
                this.TokenOfUniqueness = TOU;
            }

        }
        public class MinerToken
        {
            public byte[] MinerPKEY { get; }
            public uint mUTXOP { get; }
            public uint MiningReward { get; }

            public MinerToken(byte[] hashpkey, uint utxoP, uint reward)
            {
                this.MinerPKEY = hashpkey;
                this.mUTXOP = utxoP;
                this.MiningReward = reward;
            }
        }

        public static string _folderPath = "";

        public static uint BLOCKCHAIN_FILE_CHUNK = 10000000;
        public static uint CURRENT_UTXO_SIZE = 0;
        public static byte[] CURRENT_HASH_TARGET;
        public static bool PRINT_INFO = true;
        public static bool STOP_MINING = false;

        //--------------------------------------------------- MAIN CONSENSUS PARAMS : ( if you change this, you have to init a new blockchain ) 
        public static uint WINNING_RUN_DISTANCE = 6; // LONGEST CHAIN WIN RULES DISTANCE
        public static uint MAX_RETROGRADE = 10; // WHAT IS THE MAXIMUM OF DOWNGRADING BLOCKCHAIN FOR A LIGHT FORK.
        public static uint TARGET_CLOCK = 42; // 2016. NEW HASH TARGET REQUIRED EVERY TARGET_CLOCKth BLOCK
        public static uint TIMESTAMP_TARGET = 11; // TIMESTAMP BLOCK SHOULD BE HIGHER THAN MEDIAN OF LAST TIMESTAMP_TARGETth BLOCK
        public static uint TARGET_TIME = 40320; // 1209600 . number of seconds a block should be mined 10 *  ---> WE SHOULD GET ONE BLOCK EVERY 10S . this is working !!! 
        public static uint TARGET_DIVIDER_BOUNDARIES = 4; // 4. LIMIT OF NEW TARGET BOUNDARIES (QUARTER + AND QUARTER - )
        public static uint FIRST_UNIX_TIMESTAMP = 1598981949;
        public static uint NATIVE_REWARD = 50; // COIN GIVE TO FIRST REWARD_DIVIDER_CLOCKth BLOCK
        public static uint REWARD_DIVIDER_CLOCK = 210000; // NUMBER OF BLOCK BEFORE NATIVE REWARD SHOULD BE HALFED
        public static byte[] MAXIMUM_TARGET = StringToByteArray("00000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"); //< MAX HASH TARGET. MINIMUM DIFFICULTY.
                                                                                                                                     //--------------------------------------------------------------------------------------------------------------------------

        //--------------------------------------- BROADCAST INFO --------------------------------------------
        public class BroadcastInfo
        {
            public byte flag { get; }
            public string filePath { get; }
            public byte header { get; }
            public BroadcastInfo(byte fl, byte head = 1, string fp = "")
            {
                this.flag = fl;
                this.filePath = fp;
                this.header = head;
            }
        }
        public static network NT;
        public static List<string> PendingDLBlocks = new List<string>();
        public static List<string> PendingDLTXs = new List<string>();
        public static List<Tuple<bool, string>> PendingBlockFiles = new List<Tuple<bool, string>>();
        public static List<Tuple<bool, string>> PendingPTXFiles = new List<Tuple<bool, string>>();
        public static uint BROADCAST_BLOCKS_LIMIT = 30; // MAX NUMBER OF BLOCK I WANT TO BROADCAST WHEN UPLOADING MY BC. IF 0. BROADCAST THE FULL. 
        public static uint BROADCAST_FULL_BLOCKCHAIN_CLOCK = 30; // I SHOULD BROADCAST THE FULL EVERY HOUR... like SET A CLOCK HERE ( minute ) // should be 60 
        public static uint LATEST_FBROADCAST_TICK = 0;
        public static List<BroadcastInfo> BroadcastQueue = new List<BroadcastInfo>();
        public static List<string> peerRemovalQueue = new List<string>();
        public static List<string> dlRemovalQueue = new List<string>();

        //-------------------------------------------------------------------------- MINING SETTING
        public static byte[] MYMINERPKEY = new byte[32];
        public static uint MYUTXOPOINTER = 0;
        public static uint MAXLOCKTIMESETTING = 10000;
        public static uint NTIMES = 0;
        public static bool MININGENABLED = false;
        //------------------------------------------------------------------

        static void Main(string[] args)
        {
           
            //arduino.Initialize();
            CheckFilesAtRoot();
            VerifyFiles();
            PrintArgumentInfo();
            new Thread(() =>
            {
                Thread.CurrentThread.IsBackground = true;
                GetInput();
            }).Start();
            /*
            new Thread(() =>
            {
                Thread.CurrentThread.IsBackground = true;
                MagicKey();
            }).Start();
            */
            while (true)
            {
                try
                {
                    // ------------- PART 1
                    for (int i = PendingDLBlocks.Count - 1; i >= 0; i--)
                    {
                        Print("will concatenate dl at " + i.ToString() + PendingDLBlocks[i]);
                        PendingBlockFiles.Add(new Tuple<bool, string>(false, ConcatenateDL(PendingDLBlocks[i])));
                        Print(" we added " + PendingBlockFiles[i].Item2);
                        PendingDLBlocks.RemoveAt(i);
                    }
                    for (int i = PendingDLTXs.Count - 1; i >= 0; i--)
                    {
                        PendingPTXFiles.Add(new Tuple<bool, string>(false, ConcatenateDL(PendingDLTXs[i])));
                        PendingDLTXs.RemoveAt(i);
                    }
                    // ------------- PART 2
                    for (int i = PendingBlockFiles.Count - 1; i >= 0; i--) // un bloc est relancé deux fois ... 
                    {

                        ProccessTempBlocks(PendingBlockFiles[i].Item2, PendingBlockFiles[i].Item1);
                        PendingBlockFiles.RemoveAt(i); // 
                    }
                    for (int i = PendingPTXFiles.Count - 1; i >= 0; i--)
                    {
                        ProccessTempTXforPending(PendingPTXFiles[i].Item2, PendingPTXFiles[i].Item1);
                        PendingPTXFiles.RemoveAt(i);
                    }
                    if (PendingBlockFiles.Count == 0 && PendingPTXFiles.Count == 0 && BroadcastQueue.Count > 0)
                    {
                        // clean files containing pID in dll folder...
                        foreach (string s in dlRemovalQueue)
                        {
                            string[] files = Directory.GetFiles(Program._folderPath + "net");
                            foreach (string f in files)
                            {
                                if (f.Contains(s.ToString()))
                                {
                                    File.Delete(f);
                                }
                            }
                            Print("will delete files with " + s.ToString());
                        }
                        dlRemovalQueue = new List<string>();

                        if (NT != null)
                        {

                            // first remove the extendedpeer if need to be cleaned ...  
                            for (int n = peerRemovalQueue.Count - 1; n >= 0; n--)
                            {
                                string ip = peerRemovalQueue[n];
                                for (int i = NT.mPeers.Count - 1; i >= 0; i--)
                                {
                                    if (NT.mPeers[i].IP == ip)
                                    {
                                        NT.mPeers[i].Peer.Close();
                                        string _ip = NT.mPeers[i].IP;
                                        Int32 Port = 13000; //....
                                        NT.mPeers.RemoveAt(i);
                                        new Thread(() =>
                                        {
                                            Thread.CurrentThread.IsBackground = true;
                                            NT.Connect(ip, Port);
                                        }).Start();
                                        Print("peers " + _ip + " removed due to inactivity!");
                                        peerRemovalQueue.RemoveAt(n);
                                        break;
                                    }
                                }
                            }
                            bool _cS = false;
                            foreach (network.ExtendedPeer ex in NT.mPeers)
                            {
                                if (ex.currentlySending)
                                {
                                    _cS = true;
                                    break;
                                }
                            }
                            if (!_cS)
                            {
                                BroadCast(BroadcastQueue[0]);
                            }
                            else
                            {
                                //Console.WriteLine("currently sending");
                            }

                        }
                        else
                        {
                            PendingBlockFiles = new List<Tuple<bool, string>>();
                            PendingPTXFiles = new List<Tuple<bool, string>>();
                            BroadcastQueue = new List<BroadcastInfo>();
                        }
                    }
                    if ( PendingBlockFiles.Count == 0 && BroadcastQueue.Count == 0 && MININGENABLED && NT != null) // only mine when there is no pendingblock. 
                    {
                        if (NTIMES == 0)
                        {
                                Console.WriteLine("mining in finito");
                                // wait that pendingblockfiles are empty and broadcast is empty
                              
                                if (STOP_MINING)
                                {
                                    STOP_MINING = false;
                                    MININGENABLED = false;
                                }
                                // thread this ... .
                                string winblockPath = StartMining(MYMINERPKEY, MYUTXOPOINTER, MAXLOCKTIMESETTING, 1);
                                // need to thread this stuff ... 
                                if (winblockPath.Length != 0)
                                {

                                    PendingBlockFiles.Add(new Tuple<bool, string>(true, winblockPath));
                                }
                                else
                                {
                                    Console.WriteLine("le chemin d'acces au bloc miné a été vide... ");
                                }
                        }
                        else
                        {
                            Console.WriteLine("start mining " + NTIMES + " times ");
                            string winblockPath = StartMining(MYMINERPKEY, MYUTXOPOINTER, MAXLOCKTIMESETTING,NTIMES);
                            if (winblockPath.Length != 0)
                            {
                                PendingBlockFiles.Add(new Tuple<bool, string>(true, winblockPath));
                            }
                            else
                            {
                                Console.WriteLine("le chemin d'acces au bloc miné a été vide... ");
                            }
                            MININGENABLED = false;

                        }
                    }
                }
                catch ( Exception e)
                {
                    if ( e is NullReferenceException || e is ArgumentOutOfRangeException || e is ArgumentNullException || e is FileNotFoundException)
                    {
                        RemoveAllConcatenateDL();
                        PendingDLBlocks = new List<string>();
                        PendingDLTXs = new List<string>();
                        PendingBlockFiles = new List<Tuple<bool, string>>();
                        PendingPTXFiles = new List<Tuple<bool, string>>();
                        BroadcastQueue = new List<BroadcastInfo>();
                        peerRemovalQueue = new List<string>();
                        dlRemovalQueue = new List<string>();
                        Console.WriteLine(e.ToString());
                        // remove net temp .... 
                    }
                    else
                    {
                        Print(e.ToString());
                        return;
                    }
                   
                    
                }
                
            }

        }

        public static void BroadCast(BroadcastInfo b)
        {

            uint unixTimestamp = (uint)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalMinutes; // min ! 

            switch (b.flag)
            {
                case 1:
                    NT.BroadcastFile(b.filePath, b.header);
                    BroadcastQueue.RemoveAt(0);
                    break;
                case 2:
                    if (unixTimestamp > LATEST_FBROADCAST_TICK + BROADCAST_FULL_BLOCKCHAIN_CLOCK)
                    {
                        //NT.BroadcastFile(GetLatestBlockChainFilePath(), 1);
                        uint latestIndex = RequestLatestBlockIndex(true);
                        Print("broadcast = " + latestIndex);
                        NT.BroadcastBlockchain(1, latestIndex);
                        BroadcastQueue = new List<BroadcastInfo>();
                        LATEST_FBROADCAST_TICK = unixTimestamp;
                    }
                    else
                    {
                        uint latestIndex = RequestLatestBlockIndex(true);
                        int startI = (int)(latestIndex - BROADCAST_BLOCKS_LIMIT);
                        Print("broadcast = " + latestIndex);
                        if (startI < 1) { startI = 1; ; }
                        NT.BroadcastBlockchain((uint)startI, latestIndex);
                        BroadcastQueue.RemoveAt(0);

                    }
                    break;
            }




        }

        public static void CheckFilesAtRoot() // check if file are in folder to process
        {
            _folderPath = AppDomain.CurrentDomain.BaseDirectory;
            Print(_folderPath);

            if (!File.Exists(_folderPath + "genesis"))
            {
                CreateGenesis();
            }
            if (!Directory.Exists(_folderPath + "net"))
            {
                Directory.CreateDirectory(_folderPath + "net");
            }
            else
            {
                Directory.Delete(_folderPath + "net", true);
                Directory.CreateDirectory(_folderPath + "net");
            }
            if (!Directory.Exists(_folderPath + "blockchain"))
            {
                Directory.CreateDirectory(_folderPath + "blockchain");
                File.WriteAllBytes(_folderPath + "blockchain/0", new byte[4]);
                AppendBytesToFile(_folderPath + "blockchain/0", File.ReadAllBytes(_folderPath + "genesis"));
                File.WriteAllBytes(_folderPath + "blockchain/1", new byte[4]);
            }
            if (!File.Exists(_folderPath + "utxos"))
            {
                File.WriteAllBytes(_folderPath + "utxos", new byte[4]);
            }
            if (!File.Exists(_folderPath + "ptx"))
            {
                File.Create(_folderPath + "ptx");
            }
            if (!Directory.Exists(_folderPath + "fork"))
            {
                Directory.CreateDirectory(_folderPath + "fork");
            }

            CURRENT_UTXO_SIZE = (uint)new FileInfo(_folderPath + "utxos").Length;
            UpdateHashTarget();
        }
        public static void CreateGenesis()
        {
            byte[] gen = Convert.FromBase64String("im a a genesis block");
            for (int i = 0; i < 10; i++)
            {
                gen = ComputeSHA256(gen);
            }
            BigInteger b1 = BytesToUint256(MAXIMUM_TARGET);
            byte[] firsttarget = Uint256ToByteArray(b1); //< firsttarget is correctly write! 
            Block Genesis = new Block(0, gen, gen, new List<Tx>(), FIRST_UNIX_TIMESTAMP, new MinerToken(new byte[32], 0, 0), firsttarget, 0);

            byte[] bytes = BlockToBytes(Genesis);
            File.WriteAllBytes(_folderPath + "genesis", bytes);
        }
        public static void VerifyFiles()
        {
            // we first verify every blockchain file
            string[] files = Directory.GetFiles(_folderPath + "blockchain");
            foreach (string s in files)
            {
                if (!isHeaderCorrectInBlockFile(s))
                {
                    if (ValidYesOrNo("[WARNING] Your blockchain data is corrupted. Should reinitialize all files.")) { ClearAllFiles(); CheckFilesAtRoot(); return; }
                }

            }
            // then we verify every fork
            files = Directory.GetFiles(_folderPath + "fork");
            foreach (string s in files)
            {
                if (!isHeaderCorrectInBlockFile(s))
                {
                    if (ValidYesOrNo("[WARNING] Fork file " + s + " corrupted. Should delete this fork file ")) { File.Delete(s); }
                }

            }
            // then we verify utxo set  -> reminder : header is 4 bytes. (currency volume ). UTXO FORMAT is 40 bytes.
            uint fLenght = (uint)new FileInfo(_folderPath + "utxos").Length;
            if (fLenght < 4) { Print("utxo set file corrupted"); }
            fLenght -= 4;
            if (fLenght % 40 != 0 && fLenght != 4)
            {
                if (ValidYesOrNo("[WARNING] UTXO Set file corrupted. Should rebuild UTXO Set. ")) { BuildUTXOSet(); }
            } // we should absolutely then rebuild the utxo set. 
            // then we verify ptx  -> no header here. TX FORMAT is 1100 bytes.
            fLenght = (uint)new FileInfo(_folderPath + "ptx").Length;
            if (fLenght != 0 && fLenght % 1100 != 0)
            {
                if (ValidYesOrNo("[WARNING] PTX file corrupted. Should reinitialize ptx file ")) { File.Delete(_folderPath + "ptx"); CheckFilesAtRoot(); }
            }
        }
        
        //------------------------ BYTE MANIP ---------------------

        //-----------------    ARITH 256 BIT -------------------

        public static string HexToDecimal(string hex)
        {
            List<int> dec = new List<int> { 0 };   // decimal result

            foreach (char c in hex)
            {
                int carry = Convert.ToInt32(c.ToString(), 16);

                for (int i = 0; i < dec.Count; ++i)
                {
                    int val = dec[i] * 16 + carry;
                    dec[i] = val % 10;
                    carry = val / 10;
                }

                while (carry > 0)
                {
                    dec.Add(carry % 10);
                    carry /= 10;
                }
            }

            var chars = dec.Select(d => (char)('0' + d));
            var cArr = chars.Reverse().ToArray();
            return new string(cArr);
        }
        

        public static void FatalErrorHandler(uint err, string msg = "")
        {

            if (ValidYesOrNo("[FATAL ERROR] Should reinit chain and close app : " + msg)) { ClearAllFiles(); Environment.Exit(0); }

        }

        public static byte[] StringToByteArray(string hex)
        {
            return Enumerable.Range(0, hex.Length)
                             .Where(x => x % 2 == 0)
                             .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                             .ToArray();
        }
      
      
    }


}
