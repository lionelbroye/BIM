﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Diagnostics;
using System.Numerics;
using firstchain.arith256;
using System.Threading;
using System.Timers;

namespace firstchain
{
    class FileManipulation
    {

        public static MemoryMappedFile MemFile(string path) //< CONSTRUCTOR TO CREATE A  MAPPED FILE with fileshare.read ... 
        {
            return MemoryMappedFile.CreateFromFile(
                      //include a readonly shared stream
                      File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read),
                      //not mapping to a name
                      null,
                      //use the file's actual size
                      0L,
                      //read only access
                      MemoryMappedFileAccess.Read,
                      //not configuring security
                      null,
                      //adjust as needed
                      HandleInheritability.None,
                      //close the previously passed in stream when done
                      false);

        }
        public static byte[] GetBytesFromFile(uint startIndex, uint length, string _filePath)
        {
            // using (MemoryMappedFile memoryMappedFile = MemoryMappedFile.CreateFromFile(_filePath)) 
            //{
            // using (MemoryMappedViewStream memoryMappedViewStream = memoryMappedFile.CreateViewStream(startIndex, length, MemoryMappedFileAccess.Read))
            using (MemoryMappedFile memFile = MemFile(_filePath))
            {
                using (MemoryMappedViewStream memoryMappedViewStream = memFile.CreateViewStream(startIndex, length, MemoryMappedFileAccess.Read))
                {
                    byte[] result = new byte[length];
                    for (uint i = 0; i < length; i++)
                    {
                        result[i] = (byte)memoryMappedViewStream.ReadByte();
                    }

                    return result;
                }
            }
        }
        public static void OverWriteBytesInFile(uint startIndex, string _filePath, byte[] bytes) // can result an error. cant use file get length. 
        {

            using (MemoryMappedFile memoryMappedFile = MemoryMappedFile.CreateFromFile(_filePath))
            {
                using (MemoryMappedViewStream memoryMappedViewStream = memoryMappedFile.CreateViewStream(startIndex, bytes.Length))
                {
                    memoryMappedViewStream.WriteAsync(bytes, 0, bytes.Length);
                }
            }
        }
        public static void AppendBytesToFile(string _filePath, byte[] bytes)
        {

            using (FileStream f = new FileStream(_filePath, FileMode.Append))
            {
                f.Write(bytes, 0, bytes.Length);
            }

        }
        public static void TruncateFile(string _filePath, uint length) // can result an error. cant use file get length. 
        {
            FileInfo fi = new FileInfo(_filePath);
            FileStream fs = new FileStream(_filePath, FileMode.Open);

            fs.SetLength(fi.Length - length);
            fs.Close();
        }

        public static void RemoveAllConcatenateDL()
        {
            string[] files = Directory.GetFiles(_folderPath + "net");
            foreach (string s in files)
            {
                if (!s.Replace(_folderPath + "net", "").Contains("_"))
                {
                    File.Delete(s);
                }
            }
        }
        public static string ConcatenateDL(string index)
        {
            string[] files = Directory.GetFiles(_folderPath + "net");
            string _path = _folderPath + "net/" + index.ToString();
            File.WriteAllBytes(_path, new byte[0]); // missing 4 bytes // USE THIS FOR CREATING A FILE! NO FILECREATE SVP! 
            List<uint> flist = new List<uint>();
            foreach (string s in files)
            {

                if (s.Contains(_path))
                {
                    uint result;
                    if (uint.TryParse(s.Replace(_path + "_", ""), out result))
                    {
                        flist.Add(Convert.ToUInt32(s.Replace(_path + "_", "")));
                    }

                }
            }
            flist.Sort();
            foreach (uint i in flist)
            {
                string fPath = _path + "_" + i.ToString();
                AppendBytesToFile(_path, File.ReadAllBytes(fPath));
                File.Delete(fPath);
            }
            Print(new FileInfo(_path).Length.ToString());
            return _path;
        }

        public static void ClearAllFiles() // CLEAR ALL FILES ( GENESIS, UTXO SET, PENDING TRANSACTION, FORKS, AND BLOCKCHAIN FILES. 
        {
            _folderPath = AppDomain.CurrentDomain.BaseDirectory;
            if (File.Exists(_folderPath + "genesis"))
            {
                File.Delete(_folderPath + "genesis");
            }
            if (File.Exists(_folderPath + "ptx"))
            {
                File.Delete(_folderPath + "ptx");
            }
            if (File.Exists(_folderPath + "utxos"))
            {
                File.Delete(_folderPath + "utxos");
            }
            if (Directory.Exists(_folderPath + "fork"))
            {
                Directory.Delete(_folderPath + "fork", true);
            }
            if (Directory.Exists(_folderPath + "blockchain"))
            {
                Directory.Delete(_folderPath + "blockchain", true);
            }
            Print("All files have been cleared.");
        }

        public static void UpgradeUTXOSet(Block b) //< Apply when changing Official Blockchain Only. OverWriting UTXO depend of previous transaction. Produce dust.
        {
            foreach (Tx TX in b.Data)
            {
                UTXO utxo = GetOfficialUTXOAtPointer(TX.sUTXOP);
                if (utxo == null) { FatalErrorHandler(0, "no utxo found during upgrade utxo set"); return; } // FATAL ERROR 
                utxo = UpdateVirtualUTXO(TX, utxo, false);
                OverWriteUTXOAtPointer(TX.sUTXOP, utxo);
                if (TX.rUTXOP != 0)
                {
                    utxo = GetOfficialUTXOAtPointer(TX.rUTXOP);
                    if (utxo == null) { FatalErrorHandler(0, "no utxo found during upgrade utxo set"); return; } // FATAL ERROR
                    utxo = UpdateVirtualUTXO(TX, utxo, false);
                    OverWriteUTXOAtPointer(TX.rUTXOP, utxo);
                }
                else
                {
                    utxo = new UTXO(TX.rHashKey, TX.Amount, 0);
                    AddDust(utxo);

                }
            }
            if (b.minerToken.mUTXOP != 0)
            {
                UTXO utxo = GetOfficialUTXOAtPointer(b.minerToken.mUTXOP);
                if (utxo == null) { FatalErrorHandler(0, "no utxo found during upgrade utxo set"); return; } // FATAL ERROR
                uint mSold = utxo.Sold + b.minerToken.MiningReward;
                uint mTOU = utxo.TokenOfUniqueness + 1;
                OverWriteUTXOAtPointer(b.minerToken.mUTXOP, new UTXO(b.minerToken.MinerPKEY, mSold, mTOU));
            }
            else
            {
                UTXO utxo = new UTXO(b.minerToken.MinerPKEY, b.minerToken.MiningReward, 0);
                AddDust(utxo);
            }
            // overwrite currency_volume header. 
            uint actual_volume = BitConverter.ToUInt32(GetBytesFromFile(0, 4, _folderPath + "utxos"), 0);
            actual_volume += GetMiningReward(b.Index);
            OverWriteBytesInFile(0, _folderPath + "utxos", BitConverter.GetBytes(actual_volume));
        }
        public static void DownGradeUTXOSet(uint index) //< Apply when changing Official Blockchain Only. OverWriting UTXO depend of previous transaction. Compute dust.
        {
            uint DustCount = 0;
            for (uint i = RequestLatestBlockIndex(true); i > index; i--)
            {
                if (i == uint.MaxValue) { break; }
                Block b = GetBlockAtIndex(i);
                if (b == null) { FatalErrorHandler(0, "no block found during downgrade utxo set"); return; } // FATAL ERROR
                if (b.minerToken.mUTXOP != 0)
                {
                    UTXO utxo = GetOfficialUTXOAtPointer(b.minerToken.mUTXOP);
                    if (utxo == null) { FatalErrorHandler(0, "no utxo found during downgrade utxo set"); return; } // FATAL ERROR
                    uint mSold = utxo.Sold - b.minerToken.MiningReward;
                    uint mTOU = utxo.TokenOfUniqueness - 1;
                    OverWriteUTXOAtPointer(b.minerToken.mUTXOP, new UTXO(b.minerToken.MinerPKEY, mSold, mTOU));
                }
                else
                {
                    DustCount++;
                }
                for (int a = b.Data.Count - 1; a >= 0; a--)
                {
                    if (a == uint.MaxValue) { break; }
                    Tx TX = b.Data[a];
                    UTXO utxo = GetOfficialUTXOAtPointer(TX.sUTXOP);
                    if (utxo == null) { FatalErrorHandler(0, "no utxo found during downgrade utxo set"); return; } // FATAL ERROR
                    utxo = UpdateVirtualUTXO(TX, utxo, true);
                    OverWriteUTXOAtPointer(TX.sUTXOP, utxo);
                    if (TX.rUTXOP != 0)
                    {
                        utxo = GetOfficialUTXOAtPointer(TX.rUTXOP);
                        if (utxo == null) { FatalErrorHandler(0, "no utxo found during downgrade utxo set"); return; } // FATAL ERROR
                        utxo = UpdateVirtualUTXO(TX, utxo, true);
                        OverWriteUTXOAtPointer(TX.rUTXOP, utxo);
                    }
                    else
                    {
                        DustCount++;
                    }
                }

            }
            if (!RemoveDust(DustCount)) { FatalErrorHandler(0, "bad dust removing during downgrade utxo set"); return; } // FATAL ERROR
            OverWriteBytesInFile(0, _folderPath + "utxos", BitConverter.GetBytes(GetCurrencyVolume(index)));
        }
        public static bool OverWriteUTXOAtPointer(uint pointer, UTXO towrite)
        { // CAN RETURN FALSE

            if (pointer < 4 || pointer > CURRENT_UTXO_SIZE - 40) { return false; }
            byte[] bytes = UTXOToBytes(towrite);
            OverWriteBytesInFile(pointer, _folderPath + "utxos", bytes);
            return true;
        }
        public static void AddDust(UTXO utxo)
        {

            using (FileStream f = new FileStream(_folderPath + "utxos", FileMode.Append))
            {
                byte[] bytes = UTXOToBytes(utxo);
                f.Write(bytes, 0, bytes.Length);
            }
            CURRENT_UTXO_SIZE += 40;
        }
        public static bool RemoveDust(uint nTime)
        { //< CAN RETURN FALSE

            uint DustsLength = nTime * 40;
            if (CURRENT_UTXO_SIZE < DustsLength + 4) { return false; }
            FileStream fs = new FileStream(_folderPath + "utxos", FileMode.Open);
            fs.SetLength(CURRENT_UTXO_SIZE - DustsLength);
            fs.Close();
            CURRENT_UTXO_SIZE -= DustsLength;
            return true;
        }

        public static uint GetUTXOPointer(byte[] pKey) // return a pointer from the SHA256 pKey UTXO in the UTXO Set. They are
        {
            uint byteOffset = 4;
            while (true)
            {
                if (byteOffset >= CURRENT_UTXO_SIZE) { return 0; }
                UTXO utxo = BytesToUTXO(GetBytesFromFile(byteOffset, 40, _folderPath + "utxos"));
                if (utxo.HashKey.SequenceEqual(pKey))
                {
                    return byteOffset;
                }
                byteOffset += 40;
            }

        }


        public static void UpdatePendingTXFileB(string _filePath)
        {
            uint firstTempIndex = BitConverter.ToUInt32(GetBytesFromFile(4, 8, _filePath), 0);
            uint latestTempIndex = BitConverter.ToUInt32(GetBytesFromFile(0, 4, _filePath), 0);
            for (uint i = firstTempIndex; i < latestTempIndex + 1; i++)
            {
                Block b = GetBlockAtIndexInFile(i, _filePath);
                if (b == null) { return; }
                UpdatePendingTXFile(b);
            }
        }
        //------------------------ CONSENSUS ---------------------
        public static void UpdatePendingTXFile(Block b) // delete all TX in pending if they are include in the block ( just with verifying pkey & tou)
        {
            uint byteOffset = 0;
            FileInfo f = new FileInfo(_folderPath + "ptx");
            int fl = (int)f.Length;
            while (byteOffset < fl)
            {
                Tx TX = BytesToTx(GetBytesFromFile(byteOffset, 1100, _folderPath + "ptx"));
                if (TX == null) { FatalErrorHandler(0, "no tx found in data during update pending tx file"); return; } // FATAL ERROR
                foreach (Tx BTX in b.Data)
                {
                    if (BTX == null) { FatalErrorHandler(0, "no tx found in builder during update pending tx file"); return; } // FATAL ERROR
                    if (TX.sPKey.SequenceEqual(BTX.sPKey) && TX.TokenOfUniqueness == BTX.TokenOfUniqueness)
                    {
                        // flip bytes then truncate
                        byte[] lastTX = GetBytesFromFile((uint)fl - 1100, 1100, _folderPath + "ptx");
                        OverWriteBytesInFile(byteOffset, _folderPath + "ptx", lastTX);
                        TruncateFile(_folderPath + "ptx", 1100);
                        f = new FileInfo(_folderPath + "ptx");
                        fl = (int)f.Length;
                        break;
                    }
                }

                byteOffset += 1100;

            }
        }
        public static void CleanOldPendingTX(bool onlyForks)// remove out-to-date locktime TX in Forks + PTX file if needed. 
        {
            string[] forkfiles = Directory.GetFiles(_folderPath + "fork");
            List<string> forkdel = new List<string>();
            uint unixTimestamp = (uint)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            foreach (string s in forkfiles)
            {
                uint firstIndex = BitConverter.ToUInt32(GetBytesFromFile(4, 8, s), 0);
                uint latestIndex = BitConverter.ToUInt32(GetBytesFromFile(0, 4, s), 0);
                for (uint i = firstIndex; i < latestIndex + 1; i++)
                {
                    Block b = GetBlockAtIndexInFile(i, s);
                    if (b == null) { FatalErrorHandler(0, "no block found during cleaning old pending tx file"); return; } // FATAL ERROR
                    foreach (Tx TX in b.Data)
                    {
                        if (TX.LockTime < unixTimestamp && !forkdel.Contains(s))
                        {
                            forkdel.Add(s);
                        }
                    }
                }
            }
            foreach (string s in forkdel)
            {
                File.Delete(s);
            }
            if (!onlyForks)
            {
                uint byteOffset = 0;
                FileInfo f = new FileInfo(_folderPath + "ptx"); // clean out to date ptx and also if there are include
                int fl = (int)f.Length;
                while (byteOffset < fl)
                {
                    Tx TX = BytesToTx(GetBytesFromFile(byteOffset, 1100, _folderPath + "ptx"));
                    if (TX == null) { FatalErrorHandler(0, "no tx found in data during cleaning pending tx file"); return; } // FATAL ERROR
                    bool _del = false;
                    if (TX.LockTime < unixTimestamp) { _del = true; }
                    if (_del)
                    {
                        // flip bytes then truncate
                        byte[] lastTX = GetBytesFromFile((uint)fl - 1100, 1100, _folderPath + "ptx"); // FATAL ERROR
                        OverWriteBytesInFile(byteOffset, _folderPath + "ptx", lastTX);
                        TruncateFile(_folderPath + "ptx", 1100);
                        f = new FileInfo(_folderPath + "ptx");
                        fl = (int)f.Length;

                    }

                    byteOffset += 1100;

                }
            }
        }


        public static string ConcatenateForks(string _path1, string _path2, uint endIndex)
        {
            // will get block of _path1 until endindex(not include) , then procceed to write full block of path2
            string newForkPath = GetNewForkFilePath();
            File.WriteAllBytes(newForkPath, new byte[4]);
            uint startIndex = RequestLatestBlockIndex(true);
            uint LastIndex = RequestLatestBlockIndexInFile(_path2);
            for (uint i = startIndex + 1; i < endIndex; i++)
            {
                Block b = GetBlockAtIndexInFile(i, _path1);
                if (b == null) { File.Delete(_path2); return ""; } // FATAL ERROR
                byte[] bytes = BlockToBytes(b);
                AppendBytesToFile(newForkPath, bytes);
            }
            for (uint i = endIndex; i < LastIndex + 1; i++)
            {
                Block b = GetBlockAtIndexInFile(i, _path2);
                if (b == null) { File.Delete(_path2); FatalErrorHandler(0, "no block found in data during concatening forks file"); return ""; } // FATAL ERROR
                byte[] bytes = BlockToBytes(b);
                AppendBytesToFile(newForkPath, bytes);
                UpdatePendingTXFile(b);
            }
            OverWriteBytesInFile(0, newForkPath, BitConverter.GetBytes(LastIndex));
            Print("will delete " + _path2);
            File.Delete(_path2);
            return newForkPath;
        }
        public static void DowngradeOfficialChain(uint pointer) //< downgrade blockchain to specific length ( block#pointer not included!)
        {
            uint latestIndex = RequestLatestBlockIndex(true);
            int bytelength = 0;
            for (uint i = pointer + 1; i < latestIndex + 1; i++)
            {
                Block b = GetBlockAtIndex(i);
                if (b == null) { FatalErrorHandler(0, "no block found in data during downgrading chain"); return; } // FATAL ERROR
                bytelength += BlockToBytes(b).Length;
            }
            // we know the exact length of bytes we have to truncate.... we can use this value to erase blockchain part
            while (true)
            {
                string filePath = GetLatestBlockChainFilePath();
                FileInfo f = new FileInfo(filePath);
                if (bytelength > f.Length)
                {
                    File.Delete(filePath);
                    bytelength -= (int)f.Length;
                    bytelength += 4; // padding header
                }
                else
                {
                    TruncateFile(filePath, (uint)bytelength);
                    break;
                }
            }

            OverWriteBytesInFile(0, GetLatestBlockChainFilePath(), BitConverter.GetBytes(pointer));
            Print("Blockchain Downgraded at " + pointer);
        }
        public static void AddBlocksToOfficialChain(string filePath, bool needPropagate)
        {
            // GET THE LATEST BLOCKCHAIN FILE PATH.->
            string blockchainPath = GetLatestBlockChainFilePath();

            uint firstTempIndex = BitConverter.ToUInt32(GetBytesFromFile(4, 8, filePath), 0);
            uint latestTempIndex = RequestLatestBlockIndexInFile(filePath);
            //Print(latestTempIndex);
            for (uint i = firstTempIndex; i < latestTempIndex + 1; i++)
            {
                Block b = GetBlockAtIndexInFile(i, filePath);
                if (b == null) { FatalErrorHandler(0, "no block found in data during updating official chain"); return; } // FATAL ERROR
                PrintBlockData(b);
                byte[] bytes = BlockToBytes(b);
                FileInfo f = new FileInfo(blockchainPath);
                if (f.Length + bytes.Length > BLOCKCHAIN_FILE_CHUNK)
                {
                    string name = GetNewBlockChainFilePath();
                    File.WriteAllBytes(name, BitConverter.GetBytes(b.Index));
                    AppendBytesToFile(name.ToString(), bytes);
                }
                else
                {
                    OverWriteBytesInFile(0, blockchainPath, BitConverter.GetBytes(b.Index));
                    AppendBytesToFile(blockchainPath, bytes);
                }
                UpgradeUTXOSet(b);
                UpdatePendingTXFile(b);
            }
            if (needPropagate)
            {
                BroadcastQueue.Add(new BroadcastInfo(2, 1));
            }
            string[] forkfiles = Directory.GetFiles(_folderPath + "fork");
            foreach (string s in forkfiles)
            {
                File.Delete(s);
            }
            Print("will delete " + filePath);
            File.Delete(filePath);
            Print("Blockchain updated!");
            //arduino.SendTick("1");

        }
        public static void BuildUTXOSet()
        {
            string fPath = _folderPath + "utxos";
            File.WriteAllBytes(_folderPath + "utxos", new byte[4]);
            uint lastIndex = RequestLatestBlockIndex(true);
            for (uint i = 1; i < lastIndex + 1; i++)
            {
                Block b = GetBlockAtIndex(i);
                if (b == null) { FatalErrorHandler(0); return; } // FATAL ERROR
                UpgradeUTXOSet(b);
            }
        }

        public static UTXO GetOfficialUTXOAtPointer(uint pointer) // CAN RETURN NULL
        {
            if (pointer > CURRENT_UTXO_SIZE - 40 || pointer < 4) { return null; }
            return BytesToUTXO(GetBytesFromFile(pointer, 40, _folderPath + "utxos"));

        }

        public static Block GetBlockAtIndexInFile(uint pointer, string filePath) // Return a null Block if CANT BE BE FOUND
        {
            uint byteOffset = 4;
            // Print("want to get " + filePath);
            uint fileLength = (uint)new FileInfo(filePath).Length;
            if (fileLength < 76) { return null; }
            while (true)
            {
                if (BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0) == pointer)
                {
                    byteOffset += 68;
                    uint dsb = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                    // Print(dsb); //< this is called twice i dont fucking know why ! 
                    byteOffset -= 68;
                    if (fileLength < byteOffset + 72 + (dsb * 1100) + 80) { Print("byte missing in file"); return null; }
                    byte[] bytes = GetBytesFromFile(byteOffset, 72 + (dsb * 1100) + 80, filePath);
                    return BytesToBlock(bytes);
                }
                byteOffset += 68;
                uint ds = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                byteOffset -= 68;
                byteOffset += 72 + (ds * 1100) + 80;
                if (fileLength < byteOffset + 72) { return null; }
            }
        }
        public static Tuple<uint[], string> GetBlockPointerAtIndex(uint pointer) //< will return a Tuple  
        {

            string[] files = Directory.GetFiles(_folderPath + "blockchain");
            List<uint> flist = new List<uint>();
            foreach (string s in files) { flist.Add(Convert.ToUInt32(Path.GetFileName(s))); }
            flist.Sort();

            string filePath = "";
            foreach (uint a in flist)
            {
                uint lastIndex = RequestLatestBlockIndexInFile(_folderPath + "blockchain/" + a.ToString());
                if (lastIndex >= pointer)
                {
                    filePath = _folderPath + "blockchain/" + a.ToString();
                    break;
                }
            }
            if (filePath.Length == 0) { return null; }
            uint byteOffset = 4;
            uint fileLength = (uint)new FileInfo(filePath).Length;
            if (fileLength < 76) { return null; }
            while (true)
            {
                if (BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0) == pointer)
                {
                    byteOffset += 68;
                    uint dsb = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                    byteOffset -= 68;
                    if (fileLength < byteOffset + 72 + (dsb * 1100) + 80) { return null; }

                    return new Tuple<uint[], string>(new uint[2] { byteOffset, byteOffset + 72 + (dsb * 1100) + 80 }, filePath);

                }
                byteOffset += 68;
                uint ds = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                byteOffset -= 68;
                byteOffset += 72 + (ds * 1100) + 80;
                if (fileLength < byteOffset + 72) { return null; }
            }

        }
        public static Block GetBlockAtIndex(uint pointer) //< --- return a specific block at index. Fork NOT Included! Return a null Block if CANT BE BE FOUND
        {

            string[] files = Directory.GetFiles(_folderPath + "blockchain");
            List<uint> flist = new List<uint>();
            foreach (string s in files) { flist.Add(Convert.ToUInt32(Path.GetFileName(s))); }
            flist.Sort();

            string filePath = "";
            foreach (uint a in flist)
            {
                uint lastIndex = RequestLatestBlockIndexInFile(_folderPath + "blockchain/" + a.ToString());
                if (lastIndex >= pointer)
                {
                    filePath = _folderPath + "blockchain/" + a.ToString();
                    break;
                }
            }
            if (filePath.Length == 0) { return null; }
            uint byteOffset = 4;
            uint fileLength = (uint)new FileInfo(filePath).Length;
            if (fileLength < 76) { return null; }
            while (true)
            {
                if (BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0) == pointer)
                {
                    byteOffset += 68;
                    uint dsb = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                    byteOffset -= 68;
                    if (fileLength < byteOffset + 72 + (dsb * 1100) + 80) { return null; }
                    return BytesToBlock(GetBytesFromFile(byteOffset, 72 + (dsb * 1100) + 80, filePath));
                }
                byteOffset += 68;
                uint ds = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                byteOffset -= 68;
                byteOffset += 72 + (ds * 1100) + 80;
                if (fileLength < byteOffset + 72) { return null; }
            }

        }

        public static string GetLatestBlockChainFilePath() //<---- return latest official blockchain file
        {

            string[] files = Directory.GetFiles(_folderPath + "blockchain");
            List<uint> flist = new List<uint>();
            foreach (string s in files) { flist.Add(Convert.ToUInt32(Path.GetFileName(s))); }
            flist.Sort();
            return _folderPath + "blockchain/" + flist[flist.Count - 1].ToString();
        }
        public static string GetIndexBlockChainFilePath(uint pointer) //<---- return a filepath Official Only !
        {

            string[] files = Directory.GetFiles(_folderPath + "blockchain");
            List<uint> flist = new List<uint>();
            foreach (string s in files) { flist.Add(Convert.ToUInt32(Path.GetFileName(s))); }
            flist.Sort();

            string filePath = "";
            foreach (uint a in flist)
            {
                uint lastIndex = RequestLatestBlockIndexInFile(_folderPath + "blockchain/" + a.ToString());
                if (lastIndex >= pointer)
                {
                    filePath = _folderPath + "blockchain/" + a.ToString();
                    break;
                }
            }
            return filePath;
        }
        public static uint RequestLatestBlockIndex(bool onlyOfficial) // can do an error
        {
            if (onlyOfficial)
            {
                string s = GetLatestBlockChainFilePath();
                if (new FileInfo(s).Length < 4) { Print("file wrong format"); return uint.MaxValue; }
                return BitConverter.ToUInt32(GetBytesFromFile(0, 4, s), 0);
            }
            else
            {
                string[] files = Directory.GetFiles(_folderPath + "fork");
                string sp = GetLatestBlockChainFilePath();
                if (new FileInfo(sp).Length < 4) { Print("file wrong format"); return uint.MaxValue; }
                uint highest_BlockIndex = BitConverter.ToUInt32(GetBytesFromFile(0, 4, sp), 0); //< create an infinite loop .... 
                foreach (string s in files)
                {
                    if (new FileInfo(s).Length < 4) { Print("file wrong format"); return uint.MaxValue; }
                    uint currentIndex = BitConverter.ToUInt32(GetBytesFromFile(0, 4, s), 0);
                    if (currentIndex > highest_BlockIndex)
                    {
                        highest_BlockIndex = currentIndex;
                    }
                }
                return highest_BlockIndex;
            }

        }
        public static uint RequestLatestBlockIndexInFile(string _filePath) // can do an error
        {
            if (new FileInfo(_filePath).Length < 4) { Print("file wrong format"); return uint.MaxValue; }
            uint currentIndex = BitConverter.ToUInt32(GetBytesFromFile(0, 4, _filePath), 0);
            return currentIndex;
        }
        public static string RequestLatestIndexFilePath()
        {
            string[] files = Directory.GetFiles(_folderPath + "fork");
            uint highest_BlockIndex = RequestLatestBlockIndex(false);
            string fPath = GetLatestBlockChainFilePath();
            foreach (string s in files)
            {
                if (new FileInfo(s).Length < 4) { Print("file wrong format"); return ""; }
                uint currentIndex = BitConverter.ToUInt32(GetBytesFromFile(0, 4, s), 0);
                if (currentIndex > highest_BlockIndex)
                {
                    highest_BlockIndex = currentIndex;
                    fPath = s;
                }
            }
            return fPath;
        }
        public static string GetNewForkFilePath()
        {
            string[] files = Directory.GetFiles(_folderPath + "fork");
            return _folderPath + "fork/" + files.Length.ToString();
        }
        public static string GetNewBlockChainFilePath()
        {
            string[] files = Directory.GetFiles(_folderPath + "blockchain");
            return _folderPath + "blockchain/" + files.Length.ToString();
        }

    }
}
