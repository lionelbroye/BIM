﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Windows.Forms;
using System.Security.Cryptography;
namespace drawprogram
{
    public class PixelWrapper : Form
    {

        /*
         WE HAVE TO FIND A LINEAR COMPLEXITY IN VALIDATING PIXEL PROTOCOL ! 
         FACT---->pixel in upo are ordered by top left to bottom right [ALWAYS]
         CURRENT COMPLEXITY ---> more upo are little more it is fast to compute. [ cause we always have to full check the upo ] 
         
         */
        public static uint MAX_GAZ_PER_TRANSACTION = 1000000;
        public class Vector
        {
            public Int32 X { get; set; }
            public Int32 Y { get; set; }

            public Vector(Int32 x = 0, Int32 y = 0)
            {
                this.X = x;
                this.Y = y;
            }
        }
        public class PixExtract // size : 68 octets
        {
            public byte[] hPKey { get; } // hash de la clé publique du possesseur de ces pixels [32 octets]
            public UInt64 Index { get; } // le pointeur de la clé publique dans l'annuaire des pixels [ 8 octets ]
            public Vector[] ExtractionZone { get; } // list de 2 vecteurs des points d'extraction [ 16 octets ]
            public Vector Offset { get; } // [8 octets] // offset
            public uint BlocIndex { get; } // [4 octets] // bloc mentionné pour l'extraction
            public uint BlocTX { get; } // [4 octets] // pixel transaction mentionné lors de l'acquisition

            public PixExtract(byte[] pkey, UInt64 index, Vector[] zone, Vector off, uint bindex, uint btx)
            {
                this.hPKey = pkey;
                this.Index = index;
                this.ExtractionZone = zone;
                this.Offset = off;
                this.BlocIndex = bindex;
                this.BlocTX = btx;
            }
        }
        public class Pixel
        {
            public Vector position { get; } // 8 octets
            public uint BlocIndex { get; } // 4 octets
            public uint PixTXIndex { get; } // 4 octets
            public uint Value { get; } // 4 octets
            public Pixel(Vector pos, uint bi, uint txi, uint val)
            {
                this.position = pos;
                this.BlocIndex = bi;
                this.PixTXIndex = txi;
                this.Value = val;
            }
        }

        public class UPO  // min size = 44 octets | max size = ( for 50x50: 50044 / 500*500 : 250044 octets / 1000*1000 : 1 000 044 otctes
                          // nombre de pkey pour un annuaire de frag ( fixé a environ 10Millions d'octets
        {
            public byte[] HashKey { get; } //32 o
            public uint TokenOfUniqueness { get; } // 4 o 
            public uint Sold { get; } // 4 o 
            public uint pixelsSize { get; } // 4o 
            public List<Pixel> Pixels { get; } // * 20 octets par Pixel

            public UPO(byte[] key, uint tou, uint sold, List<Pixel> pixs)
            {
                this.HashKey = key;
                this.TokenOfUniqueness = tou;
                this.Sold = sold;
                this.pixelsSize = (uint)pixs.Count;
                this.Pixels = pixs;
            }

        }

        public static List<byte> AddBytesToList(List<byte> list, byte[] bytes)
        {
            foreach (byte b in bytes) { list.Add(b); }
            return list;
        }
        public static byte[] ListToByteArray(List<byte> list)
        {
            byte[] result = new byte[list.Count];
            for (int i = 0; i < list.Count; i++) { result[i] = list[i]; }
            return result;
        }
        public static List<Vector> PixelsToVectors(List<Pixel> Pixels)
        {

                List<Vector> result = new List<Vector>();
                foreach (Pixel pix in Pixels)
                {
                    result.Add(pix.position);
                }
                return result;
        }
        public static void ValidatingThread()
        {
            while ( true )
            {
                if (Form1.ProccessedPixel.Count > 0)
                {

                    GetValidityFromPixels(Form1.ProccessedPixel);
                }
            }
        }

        public static uint MAX_UPO_CACHE = 200;

        public  static void GetValidityFromPixels(List<List<Vector>> pix) // iterate through the blockchain ! 
        {
            // [1] load upo 
            TextBox t = Application.OpenForms["Form1"].Controls["validationInfo"] as TextBox;
            t.Invoke((MethodInvoker)(() => t.Text += "Start Validation..." + "\r\n"));

            List<UPO> upos = new List<UPO>();
            for (uint i = 0; i < MAX_UPO_CACHE; i++)
            {
                UPO upo = GetOfficialUPO_B(i);
                if ( upo != null)
                {
                    upos.Add(upo); // load in ram...
                }
                else
                {
                    break; 
                }
            }
            ulong upoCount = 0; 
            foreach (List<Vector> listvec in pix)
            {
                int minx = int.MaxValue;
                int maxx = int.MinValue;
                int miny = int.MaxValue;
                int maxy= int.MinValue; 

                foreach( Vector p in listvec)
                {
                    if ( p.X < minx)
                    {
                        minx = p.X;
                    }
                    if ( p.X > maxx)
                    {
                        maxx = p.X;
                    }
                    if (p.Y < miny)
                    {
                        miny = p.Y;
                    }
                    if (p.Y > maxy)
                    {
                        maxy = p.Y;
                    }
                }
                MessageBox.Show("square of size : " + (maxx - minx).ToString() + "x" + (maxy - miny).ToString() + " pix"    );
                // [2] load a vector path
                //byte[] myvectors = GetVectorPathFromPixelListAsBytes(listvec, 0 );
                List<Vector> myvectors = GetVectorPathFromPixelList(listvec, 0);
                for ( int n = 0; n < upos.Count; n++ )//foreach ( UPO upo in upos)
                {
                    // [3] ordered upo pixel per transaction
                    List<List<Pixel>> pixelOrdered = OrderedUPOPixelPerTX(upos[n].Pixels);
                    foreach ( List<Pixel> sortedupoPixel in pixelOrdered)
                    {
                        for ( int i = 0; i < sortedupoPixel.Count; i++ )
                        {
                            // [3] Compare Path per Path ... 
                           // byte[] upoPath = GetVectorPathFromPixelList(PixelsToVectors(sortedupoPixel), (uint)i);

                            // we can get a mode !! ... 
                            if (isPathContainsPath(sortedupoPixel, i, myvectors))
                            {
                                Vector Offset = sortedupoPixel[i].position; 
                                Vector[] ExtractionZone = new Vector[2];
                                // extraction zone is specific ... we have tricky stuff to do here ... 
                                // but we know we start at top left and stop at bottom right this is a clue !!! 
                                /* extractionzone start from minx
                                 * // we have to square pixels ... 
                                 * first vector  : minx + offset.x, miny + offset.y
                                 * first vector  :  maxx + offset.x, maxy + offset.y
                                 */
                                ExtractionZone[0] = new Vector(minx + Offset.X, miny + Offset.Y);
                                ExtractionZone[1] = new Vector(maxx + Offset.X, maxy + Offset.Y);

                                BuildPixExtraction(listvec, upos[n], upoCount + (ulong)n , ExtractionZone, Offset, sortedupoPixel[i].BlocIndex, sortedupoPixel[i].PixTXIndex, (uint)(sortedupoPixel[i].Value * listvec.Count));

                                Form1.ProccessedPixel = new List<List<Vector>>();
                                // recall the stuff
                                return;
                            }
                            /*
                            if (isPathContainsExactPath(upoPath, myvectors)) {
                                MessageBox.Show("exact pixel template found in blockchain at Offset " + i.ToString());
                                Form1.ProccessedPixel = new List<List<Vector>>();
                                return;
                            }
                            */
                        }
                    }
                }

            }
            MessageBox.Show("pixel was not found in blockchain!! ");
            Form1.ProccessedPixel = new List<List<Vector>>();
        }
        public static string SHAToHex(byte[] bytes, bool upperCase)
        {
            StringBuilder result = new StringBuilder(bytes.Length * 2);

            for (int i = 0; i < bytes.Length; i++)
                result.Append(bytes[i].ToString(upperCase ? "X2" : "x2"));

            return result.ToString();
        }
        public static void BuildPixExtraction(List<Vector> pixelindraw, UPO upo, ulong upoIndex, Vector[] ExtractionZone, Vector Offset, uint BlockID, uint TXID, uint pixsValue )
        {
            string msginfo = "";
            msginfo += "Current Key Pixel Holder     : " + SHAToHex(upo.HashKey, false) + "\r\n";
            msginfo += "Current Key Index            : " + upoIndex + "\r\n";
            msginfo += "Extract at block #           : " + BlockID.ToString() + "\r\n";
            msginfo += "Extract at Transaction #     : " + TXID.ToString() + "\r\n";
            msginfo += "Extraction Zone              : " + ExtractionZone[0].X.ToString() + ";" + ExtractionZone[0].Y.ToString() + " to " +
             ExtractionZone[1].X.ToString() + ";" + ExtractionZone[1].Y.ToString() + "\r\n";

            msginfo += "Offset applied               : " + Offset.X.ToString() +";" + Offset.Y.ToString() + "\r\n";
            msginfo += "Pixels Extracted Total Value : " + pixsValue.ToString() + "\r\n";
            msginfo += "_______________________________________________________" + "\r\n";
            MessageBox.Show(msginfo);
            PixExtract simuExtract = new PixExtract(upo.HashKey, upoIndex, ExtractionZone, Offset, BlockID, TXID);
            List<Pixel> pixsextract = GetAllPixelsFromExtractionB(simuExtract, new List<UPO>()).Item2; // could add further cache here... 
            uint val = GetValueFromPixels(pixsextract);
            if (pixsValue < val)
            {
                msginfo = "Zone is not representing your pixel -> Simulated Total Value : " + val.ToString() + "\r\n" + "Will build a group of pix extraction pixel per pixel...";
                MessageBox.Show(msginfo);
                List<PixExtract> pixextractionsperpixel = new List<PixExtract>();
                uint sumval = 0;
                uint gaz = 0;
                foreach ( Vector p in pixelindraw)
                {
                    PixExtract simuExtractB = new PixExtract(upo.HashKey, upoIndex, new Vector[2] { new Vector(p.X + Offset.X, p.Y + Offset.Y), new Vector(p.X + Offset.X +1 , p.Y + Offset.Y + 1), }, 
                        Offset, BlockID, TXID);
                    Tuple<uint, List<Pixel>> extractedResult = GetAllPixelsFromExtractionB(simuExtractB, new List<UPO>());
                    List<Pixel> pixsextractB = extractedResult.Item2; // could add further cache here... 
                    gaz += extractedResult.Item1;
                    if ( gaz >  MAX_GAZ_PER_TRANSACTION) {// avoid unvalid validation.
                        msginfo = " Unvalid Transaction.  last extraction will not be accepted."+ "\r\n";
                        break;
                    }  
                    if ( gaz == MAX_GAZ_PER_TRANSACTION) {

                        msginfo = " Gaz Limit Reach" + "\r\n";
                        uint valB = GetValueFromPixels(pixsextractB);
                        sumval += valB;
                        pixextractionsperpixel.Add(simuExtractB);
                        break;

                    }
                    else
                    {
                        uint valB = GetValueFromPixels(pixsextractB);
                        sumval += valB;
                        pixextractionsperpixel.Add(simuExtractB);
                    }
                   
                }
                msginfo += "current total value : " + sumval.ToString() + "\r\n" ;
                MessageBox.Show(msginfo);
            }
            else
            {
                // do the stuff ... like build 
            }
          

            
        }
        
        public static bool isPathContainsPath(List<Pixel> UpoPix, int startIndex, List<Vector> myPath)
        {
           
            // process every 4 bytes ... 
            for (int i = 0; i < myPath.Count; i++)
            {
                bool _isContained = false;
                foreach ( Pixel pix in UpoPix)
                {
                    if (pix.position.X == UpoPix[startIndex].position.X + myPath[i].X 
                        && pix.position.Y == UpoPix[startIndex].position.Y + myPath[i].Y)
                    {
                        _isContained = true;
                        break;
                    }
                }
                if ( !_isContained)
                {
                    return false;
                }
            }
            return true ;
        }
        public static bool isPathContainsExactPath(byte[] _pathA, byte[] _pathB)
        {
            // check if _path A contains _path B ...
            if (BoyerMoore.IndexOf(_pathA, _pathB)  != -1  )
            {
                return true;
            }
            return false;
        }
        public static List<List<Pixel>> OrderedUPOPixelPerTX(List<Pixel> upoPix)
        {
            List<List<Pixel>> result = new List<List<Pixel>>();
            List<string> bitiproccessed = new List<string>();
            for ( int i = 0; i < upoPix.Count; i++ )
            {
                string currentbiti = upoPix[i].BlocIndex.ToString() + upoPix[i].PixTXIndex.ToString();
                if (!bitiproccessed.Contains(currentbiti))
                {
                    List<Pixel> currentList = new List<Pixel>();
                    currentList.Add(upoPix[i]);
                    for ( int n = i+1; n < upoPix.Count; n++)
                    {
                        currentList.Add(upoPix[n]);
                    }
                    result.Add(currentList);
                    bitiproccessed.Add(currentbiti);
                }
            }
            return result;
        }
        public static List<Vector> GetVectorPathFromPixelList(List<Vector> pixvec, uint startOffset) // 
        {
            // pixel are pre-ordered from top left to bottom right ... 
            List<Vector> _path = new List<Vector>();
            _path.Add(new Vector());

            if (pixvec.Count < 2) { return _path; }
            for (int i = 1; i < pixvec.Count; i++)
            {
                // get offset x and offset y from stuff ... 
                int offset_x = pixvec[i].X - pixvec[i - 1].X;
                int offset_y = pixvec[i].Y - pixvec[i - 1].Y;

                _path.Add(new Vector(offset_x, offset_y));

            }

            //MessageBox.Show((_path.Count / 4).ToString());
            return _path;
        }
        public static byte[] GetVectorPathFromPixelListAsBytes(List<Vector> pixvec, uint startOffset) // 
        {
            // pixel are pre-ordered from top left to bottom right ... 
            List<byte> _path = new List<byte>();
            _path = AddBytesToList(_path, BitConverter.GetBytes((int)0));
            _path = AddBytesToList(_path, BitConverter.GetBytes((int)0));
            if ( pixvec.Count < 2) { return ListToByteArray(_path); }
            for (int i = 1; i < pixvec.Count; i++)
            {
                // get offset x and offset y from stuff ... 
                int offset_x = pixvec[i].X - pixvec[i-1].X;
                int offset_y = pixvec[i].Y - pixvec[i - 1].Y;
                _path = AddBytesToList(_path, BitConverter.GetBytes(offset_x));
                _path = AddBytesToList(_path, BitConverter.GetBytes(offset_y));

            }

            //MessageBox.Show((_path.Count / 4).ToString());
            return ListToByteArray(_path);
        }

        //-----------------------------------------------------------------------------------------------------------------------------

        public static UPO GetOfficialUPO_B(UInt64 index) // pkey has to be the hash of public key
        {
            // every pixel annuaire have an indication about the last index inside it (in 8 bytes values ) -
            string[] files = Directory.GetFiles(Form1._folderPath + "pixelstate");
            string filePath = "";
            uint readCounter = 0;
            foreach (string s in files)
            {
                UInt64 lastIndex = BitConverter.ToUInt64(GetBytesFromFile(0, 8, s), 0);
                if (lastIndex >= index)
                {
                    filePath = s;
                    break;
                }
            }

            if (filePath.Length == 0) { Console.WriteLine("unable to find a pointer for you "); return null; }
            uint fileLength = (uint)new FileInfo(filePath).Length;
            uint byteOffset = 8; // first 8 bytes header is last Index in annuaire
            while (true)
            {
                if (byteOffset >= fileLength) { Console.WriteLine("nothing here"); return null; }
                Console.WriteLine(readCounter);
                if (readCounter == index)
                {
                    byteOffset += 40; // jump to pixelsSize data... 
                    if (byteOffset + 4 >= fileLength) { Console.WriteLine("unable to get the pixel size data..." + byteOffset + " " + fileLength); return null; } // big prob
                    uint psi = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                    byteOffset -= 40;
                    return BytesToUPO(GetBytesFromFile(byteOffset, 44 + (psi * 20), filePath));
                }
                byteOffset += 40; // jump to pixelsSize data... 
                if (byteOffset + 4 >= fileLength) { return null; }
                uint ps = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                byteOffset += 4 + (ps * 20);
                readCounter++;
            }
        }
        public static UPO GetOfficialUPO(UInt64 index, byte[] pKey) // pkey has to be the hash of public key
        {

            // every pixel annuaire have an indication about the last index inside it (in 8 bytes values ) -
            string[] files = Directory.GetFiles(Form1._folderPath + "pixelstate");
            string filePath = "";
            uint readCounter = 0;
            foreach (string s in files)
            {
                UInt64 lastIndex = BitConverter.ToUInt64(GetBytesFromFile(0, 8, s), 0);
                if (lastIndex >= index)
                {
                    filePath = s;
                    break;
                }
            }

            if (filePath.Length == 0) { Console.WriteLine("no file found "); return null; }
            uint fileLength = (uint)new FileInfo(filePath).Length;
            uint byteOffset = 8; // first 8 bytes header is last Index in annuaire
            while (true)
            {
                if (byteOffset >= fileLength) { return null; }

                byte[] currentPKEY = GetBytesFromFile(byteOffset, 32, filePath);
                if (currentPKEY.SequenceEqual(pKey))
                {
                    byteOffset += 40; // jump to pixelsSize data... 
                    if (byteOffset + 4 >= fileLength) { return null; }
                    uint psi = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                    byteOffset -= 40;
                    Console.WriteLine("found at " + readCounter);
                    return BytesToUPO(GetBytesFromFile(byteOffset, 44 + (psi * 20), filePath));
                }
                byteOffset += 40; // jump to pixelsSize data... 
                if (byteOffset + 4 >= fileLength) { return null; }
                uint ps = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, filePath), 0);
                byteOffset += 4 + (ps * 20);
                readCounter++;
            }

        }
        public static UInt64 GetUPOIndex(byte[] pKey)
        {
            string[] files = Directory.GetFiles(Form1._folderPath + "pixelstate");
            ulong readCounter = 0;
            foreach (string s in files)
            {
                uint fileLength = (uint)new FileInfo(s).Length;
                uint byteOffset = 8;

                while (fileLength >= byteOffset)
                {
                    byte[] currentPKEY = GetBytesFromFile(byteOffset, 32, s);
                    if (currentPKEY.SequenceEqual(pKey))
                    {
                        return readCounter; // wtf??
                    }
                    byteOffset += 40; // jump to pixelsSize data... 
                    if (byteOffset + 4 >= fileLength) { return 0; }
                    uint ps = BitConverter.ToUInt32(GetBytesFromFile(byteOffset, 4, s), 0);
                    byteOffset += 4 + (ps * 20);
                    readCounter++;
                }
            }
            return 0;

        }
        public static Pixel BytesToPixel(byte[] bytes)
        {
            if (bytes.Length != 20) { return null; }
            byte[] posx = new byte[4];
            byte[] posy = new byte[4];
            byte[] bi = new byte[4];
            byte[] txi = new byte[4];
            byte[] val = new byte[4];
            uint byteOffset = 0;
            for (uint i = byteOffset; i < byteOffset + 4; i++)
            {
                posx[i - byteOffset] = bytes[i];
            }
            byteOffset += 4;
            for (uint i = byteOffset; i < byteOffset + 4; i++)
            {
                posy[i - byteOffset] = bytes[i];
            }
            byteOffset += 4;
            for (uint i = byteOffset; i < byteOffset + 4; i++)
            {
                bi[i - byteOffset] = bytes[i];
            }
            byteOffset += 4;
            for (uint i = byteOffset; i < byteOffset + 4; i++)
            {
                txi[i - byteOffset] = bytes[i];
            }
            byteOffset += 4;
            for (uint i = byteOffset; i < byteOffset + 4; i++)
            {
                val[i - byteOffset] = bytes[i];
            }
            byteOffset += 4;

            return new Pixel(new Vector(BitConverter.ToInt32(posx, 0), BitConverter.ToInt32(posy, 0)), BitConverter.ToUInt32(bi, 0),
                BitConverter.ToUInt32(txi, 0), BitConverter.ToUInt32(val, 0));
        }
        public static UPO BytesToUPO(byte[] bytes)
        {
            // we should secure the stuff...
            byte[] HashKey = new byte[32];
            byte[] TokenOfUniqueness = new byte[4];
            byte[] Sold = new byte[4];
            byte[] pixelsSize = new byte[4];
            List<Pixel> Pixels = new List<Pixel>();
            uint byteOffset = 0;
            for (uint i = byteOffset; i < byteOffset + 32; i++)
            {
                HashKey[i - byteOffset] = bytes[i];
            }
            byteOffset += 32;
            for (uint i = byteOffset; i < byteOffset + 4; i++)
            {
                TokenOfUniqueness[i - byteOffset] = bytes[i];
            }
            byteOffset += 4;
            for (uint i = byteOffset; i < byteOffset + 4; i++)
            {
                Sold[i - byteOffset] = bytes[i];
            }
            byteOffset += 4;
            for (uint i = byteOffset; i < byteOffset + 4; i++)
            {
                pixelsSize[i - byteOffset] = bytes[i];
            }
            byteOffset += 4;
            Console.WriteLine("pixelsize found in file : " + BitConverter.ToUInt32(pixelsSize, 0));
            for (uint i = 0; i < BitConverter.ToUInt32(pixelsSize, 0); i++)
            {
                byte[] pixelBytes = new byte[20];
                for (uint n = byteOffset; n < byteOffset + 20; n++)
                {
                    pixelBytes[n - byteOffset] = bytes[n]; //  out of range exception 
                }
                byteOffset += 20;
                Pixel pix = BytesToPixel(pixelBytes);
                if (pix == null) { return null; }
                Pixels.Add(pix);
            }
            return new UPO(HashKey, BitConverter.ToUInt32(TokenOfUniqueness, 0), BitConverter.ToUInt32(Sold, 0), Pixels);
        }
        public static MemoryMappedFile MemFile(string path) //< CONSTRUCTOR TO CREATE A  MAPPED FILE with fileshare.read ... 
        {
            return MemoryMappedFile.CreateFromFile(
                      //include a readonly shared stream
                      File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read),
                      //not mapping to a name
                      null,
                      //use the file's actual size
                      0L,
                      //read only access
                      MemoryMappedFileAccess.Read,
                      //not configuring security
                      null,
                      //adjust as needed
                      HandleInheritability.None,
                      //close the previously passed in stream when done
                      false);

        }
        public static byte[] GetBytesFromFile(uint startIndex, uint length, string _filePath)
        {
            // using (MemoryMappedFile memoryMappedFile = MemoryMappedFile.CreateFromFile(_filePath)) 
            //{
            // using (MemoryMappedViewStream memoryMappedViewStream = memoryMappedFile.CreateViewStream(startIndex, length, MemoryMappedFileAccess.Read))
            using (MemoryMappedFile memFile = MemFile(_filePath))
            {
                using (MemoryMappedViewStream memoryMappedViewStream = memFile.CreateViewStream(startIndex, length, MemoryMappedFileAccess.Read))
                {
                    byte[] result = new byte[length];
                    for (uint i = 0; i < length; i++)
                    {
                        result[i] = (byte)memoryMappedViewStream.ReadByte();
                    }

                    return result;
                }
            }
        }
        public static byte[] ComputeSHA256(byte[] msg)
        {
            SHA256 sha = SHA256.Create();
            byte[] result = sha.ComputeHash(msg);
            return result;
        }

        public static byte[] UPOToBytes(UPO upo)
        {
            if (upo == null) { return new byte[0]; }
            List<byte> Databuilder = new List<byte>();
            Databuilder = AddBytesToList(Databuilder, upo.HashKey);
            Databuilder = AddBytesToList(Databuilder, BitConverter.GetBytes(upo.TokenOfUniqueness));
            Databuilder = AddBytesToList(Databuilder, BitConverter.GetBytes(upo.Sold));
            Databuilder = AddBytesToList(Databuilder, BitConverter.GetBytes(upo.pixelsSize));
            foreach (Pixel pix in upo.Pixels)
            {
                Databuilder = AddBytesToList(Databuilder, PixelToBytes(pix));
            }

            return ListToByteArray(Databuilder);
        }
        public static byte[] PixelToBytes(Pixel pix)
        {
            if (pix == null) { return new byte[0]; }
            List<byte> Databuilder = new List<byte>();
            Databuilder = AddBytesToList(Databuilder, BitConverter.GetBytes(pix.position.X));
            Databuilder = AddBytesToList(Databuilder, BitConverter.GetBytes(pix.position.Y));
            Databuilder = AddBytesToList(Databuilder, BitConverter.GetBytes(pix.BlocIndex));
            Databuilder = AddBytesToList(Databuilder, BitConverter.GetBytes(pix.PixTXIndex));
            Databuilder = AddBytesToList(Databuilder, BitConverter.GetBytes(pix.Value));
            return ListToByteArray(Databuilder);
        }
        public static Tuple<uint, List<Pixel>> GetAllPixelsFromExtractionB(PixExtract pex, List<UPO> vUPOs)
        {
            // should return the ExtractionCPUGAZ return depending of upo.pixelssize. 
            // SCENARIO ---> 
            /*
             * EXTRACT FROM BLOCK 0 AT BLOCK 1 COST 1 000 000 states per extraction. 
             * WE SHOULD HAVE A EXTRACTION CPU GAZ LIMIT OF 1 000 000. SO FIRST TRANSACTION OF THE CHAIN SHOULD ONLY HAD ONE EXTRACTION
             * FOR EVERYONE TO GET MORE WRITING POWER, THEY HAVE TO FRAG THE MONOLITH IN SMALLER CHUNK ( BUT NOT TOO SMALL. CHUNK USEABLE BY OTHER... )
             */


            uint gaz = 0; 
            List<Pixel> exPixels = new List<Pixel>();
            UPO upo = null;
            bool _found = false;
            foreach (UPO vupo in vUPOs)
            {
                if (vupo.HashKey.SequenceEqual(pex.hPKey))
                {
                    upo = vupo;
                    _found = true;
                    break;
                }
            }
            if (!_found)
            {
                upo = GetOfficialUPO(pex.Index, pex.hPKey);
            }
            if (pex.ExtractionZone[0].X > pex.ExtractionZone[1].X) { return new Tuple<uint, List<Pixel>> (1, exPixels); }
            if (pex.ExtractionZone[0].Y > pex.ExtractionZone[1].Y) { return new Tuple<uint, List<Pixel>>(1, exPixels); }

            foreach (Pixel pix in upo.Pixels)
            {
                if (pix.BlocIndex == pex.BlocIndex && pix.PixTXIndex == pex.BlocTX &&
                    pix.position.X >= pex.ExtractionZone[0].X && pix.position.X < pex.ExtractionZone[1].X &&
                    pix.position.Y >= pex.ExtractionZone[0].Y && pix.position.Y < pex.ExtractionZone[1].Y)
                {
                    if (!exPixels.Contains(pix))
                    {
                        exPixels.Add(pix);
                    }
                }
            }
            gaz += upo.pixelsSize;
            return new Tuple<uint, List<Pixel>>(gaz, exPixels); ;
        }
        public static List<Pixel> GetAllPixelsFromExtraction(PixExtract pex, List<UPO> vUPOs)
        {
            // get the upo from pex hashbey 
            List<Pixel> exPixels = new List<Pixel>();
            UPO upo = null;
            bool _found = false;
            foreach (UPO vupo in vUPOs)
            {
                if (vupo.HashKey.SequenceEqual(pex.hPKey))
                {
                    upo = vupo;
                    _found = true;
                    break;
                }
            }
            if (!_found)
            {
                upo = GetOfficialUPO(pex.Index, pex.hPKey);
            }
            if (pex.ExtractionZone[0].X > pex.ExtractionZone[1].X) { MessageBox.Show("bad extraction zone"); return exPixels; }
            if (pex.ExtractionZone[0].Y > pex.ExtractionZone[1].Y) { MessageBox.Show("bad extraction zone"); return exPixels; }

            // get the upo as bytes ... but padding to 44 offset ! 
            List<byte> pixelupobuilder = new List<byte>();
            foreach(Pixel p in upo.Pixels) { pixelupobuilder = AddBytesToList(pixelupobuilder, PixelToBytes(p));  }
            byte[] upobytes = ListToByteArray(pixelupobuilder);

            for (int x = pex.ExtractionZone[0].X; x < pex.ExtractionZone[1].X; x++)
            {
                for (int y = pex.ExtractionZone[0].Y; y < pex.ExtractionZone[1].Y; y++)
                {
                    List<byte> spixelbuilder = new List<byte>();
                    spixelbuilder = AddBytesToList(spixelbuilder, BitConverter.GetBytes(x));
                    spixelbuilder = AddBytesToList(spixelbuilder, BitConverter.GetBytes(y));
                    spixelbuilder = AddBytesToList(spixelbuilder, BitConverter.GetBytes(pex.BlocIndex));
                    spixelbuilder = AddBytesToList(spixelbuilder, BitConverter.GetBytes(pex.BlocTX));

                    // remove the pixel value
                    int indexFound = BoyerMoore.IndexOf(upobytes, ListToByteArray(spixelbuilder));
                    if ( indexFound >= 0)
                    {
                        // get bytes from indexfound to indexfound + 20 in upobytes... 
                        byte[] bytespixel = new byte[20];
                        for (int i = indexFound; i < indexFound + 20; i++)
                        {
                            bytespixel[i - indexFound] = upobytes[i];
                        }
                        Pixel pfound = BytesToPixel(bytespixel);
                        exPixels.Add(pfound);
                    }
                }
            }
            return exPixels;
        }
        public static uint GetValueFromPixels(List<Pixel> pixs)
        {
            // what is value? price per unit? 
            uint value_per_unit = pixs[0].Value;

            return (uint)(value_per_unit * pixs.Count);
        }

    }
}
