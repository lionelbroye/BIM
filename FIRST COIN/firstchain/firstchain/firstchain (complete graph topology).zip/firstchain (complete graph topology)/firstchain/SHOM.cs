﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
namespace firstchain
{
    class SHOM
    {

        public static void GetSHOMData(int station, DateTime dateStart, DateTime dateEnd)
        {
            // annee-mois-jour
            Console.WriteLine(dateStart.Year.ToString());
            Console.WriteLine(dateStart.Month.ToString());
            Console.WriteLine(dateStart.Day.ToString());
            string datestartstr = dateStart.Year.ToString() + "-" + dateStart.Month.ToString() + "-" + dateStart.Day.ToString();
            string dateendstr = dateEnd.Year.ToString() + "-" + dateEnd.Month.ToString() + "-" + dateEnd.Day.ToString();
            string sURL;
            sURL = "https://services.data.shom.fr/maregraphie/observation/json/"+station.ToString()+"?sources=1&dtStart="+datestartstr+"&dtEnd=" + dateendstr;

            WebRequest wrGETURL;
            wrGETURL = WebRequest.Create(sURL);

            WebProxy myProxy = new WebProxy("myproxy", 80);
            myProxy.BypassProxyOnLocal = true;

            wrGETURL.Proxy = WebProxy.GetDefaultProxy();

            Stream objStream;
            try
            {
                objStream = wrGETURL.GetResponse().GetResponseStream();
            }
            catch ( Exception e)
            {
                Console.WriteLine("Server not responding with current argument.");
                return; 
            }
            

            StreamReader objReader = new StreamReader(objStream);

            string sLine = "";
            int i = 0;

            while (sLine != null)
            {
                i++;
                sLine = objReader.ReadLine();
                if (sLine != null)
                    Console.WriteLine("{0}:{1}", i, sLine);
            }


            Console.WriteLine(dateendstr);
        }

    }
}
